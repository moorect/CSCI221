/**
 * This class outputs Hello World
 * @author Chris Moore
 * @since August 22, 2012
 */
public class HelloWorld {

	public static void main (String[] arg) {
		System.out.print("Hello World");
		
	}
}
